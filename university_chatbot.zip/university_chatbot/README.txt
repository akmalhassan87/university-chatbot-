# University Assistant Chatbot

## Run on a computer

1. Install Python 3.
2. Open a terminal in this folder.
3. Install Flask:

   pip install -r requirements.txt

4. Start the chatbot:

   python app.py

5. Open this address in your browser:

   http://127.0.0.1:5000

## Put it online

Upload this project to a Python-compatible hosting service and use:
- Build/install command: pip install -r requirements.txt
- Start command: gunicorn app:app

The hosting service will then give you a public HTTPS link that can be opened on an iPhone or Android phone.

## Important

The current chatbot uses simple Python rules. You can later replace `get_response()` with an AI API or a database of your university FAQs.
