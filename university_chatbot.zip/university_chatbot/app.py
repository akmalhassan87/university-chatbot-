from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

def get_response(message):
    msg = message.lower().strip()

    if not msg:
        return "Please type a question. 😊"

    if any(word in msg for word in ["hello", "hi", "hey", "salam", "assalam"]):
        return "Hello! 👋 I’m your University Assistant. How can I help you?"

    if "admission" in msg or "admissions" in msg:
        return "For admission information, please contact the university admission office or check the latest admission notice."

    if "fee" in msg or "fees" in msg:
        return "For the latest fee details, please contact the university accounts office."

    if "attendance" in msg:
        return "Please maintain the attendance percentage required by your university. Check your department's official rules for the exact percentage."

    if "course" in msg or "courses" in msg or "program" in msg or "degree" in msg:
        return "I can help with course information. Tell me your department or degree program."

    if "exam" in msg or "exams" in msg:
        return "For exam dates and schedules, please check your university's official exam notice or student portal."

    if "assignment" in msg or "assignments" in msg:
        return "For assignment deadlines, check your course portal or ask your course instructor."

    if "bye" in msg or "goodbye" in msg:
        return "Goodbye! 👋 Have a great day."

    return "Sorry, I don't know that yet. Try asking about admissions, fees, attendance, courses, exams, or assignments."

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    message = data.get("message", "")
    return jsonify({"reply": get_response(message)})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
